/*
 Build a formatted self-review .docx from a JSON content file.
 Usage: node build_review_docx.js <content.json> <out.docx>
 Requires: npm install docx   (skill falls back to plain text if unavailable)

 content.json shape:
 {
   "title": "Mid-Year Self Review — 2026",
   "subtitle": "Name | Level",
   "note": "optional italic note",
   "sections": [
     { "heading": "1. Outcomes ...",
       "blocks": [
         {"type":"placeholder","label":"Utilization:","text":"[...]"},
         {"type":"p","text":"..."},
         {"type":"bullet","lead":"Bold lead: ","text":"rest"},
         {"type":"numbered","lead":"Title. ","text":"rest"},
         {"type":"quoted","runs":[["plain ",false],["\"quote\"",true],[" plain",false]]}
       ] }
   ]
 }
 'quoted' runs are [text, isItalic] pairs so feedback quotes render in italics inline.
*/
const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, AlignmentType, LevelFormat,
        HeadingLevel, BorderStyle } = require("docx");
const BLUE = "2E75B6", GREY = "595959", NAVY = "1F3864";
const [,, inPath, outPath] = process.argv;
if (!inPath || !outPath) { console.error("usage: node build_review_docx.js <content.json> <out.docx>"); process.exit(1); }
const c = JSON.parse(fs.readFileSync(inPath, "utf8"));
const t = (text, o) => new TextRun(Object.assign({ text }, o || {}));

function block(b) {
  if (b.type === "placeholder")
    return new Paragraph({ spacing:{after:120}, children:[t(b.label+" ",{bold:true}), t(b.text,{italics:true,color:BLUE})] });
  if (b.type === "bullet")
    return new Paragraph({ numbering:{reference:"bullets",level:0}, spacing:{after:100}, children:[t(b.lead||"",{bold:true}), t(b.text||"")] });
  if (b.type === "numbered")
    return new Paragraph({ numbering:{reference:"nums",level:0}, spacing:{after:140}, children:[t(b.lead||"",{bold:true}), t(b.text||"")] });
  if (b.type === "quoted")
    return new Paragraph({ spacing:{after:160}, children: b.runs.map(([txt, ital]) => t(txt, ital?{italics:true}:{})) });
  return new Paragraph({ spacing:{after:160}, children:[t(b.text||"")] });
}

const children = [];
children.push(new Paragraph({ spacing:{after:40}, children:[t(c.title||"Self Review",{bold:true,size:36,color:NAVY})] }));
if (c.subtitle) children.push(new Paragraph({ spacing:{after:40}, children:[t(c.subtitle,{size:24,color:GREY})] }));
if (c.note) children.push(new Paragraph({ spacing:{after:200}, children:[t(c.note,{italics:true,size:18,color:GREY})] }));
for (const s of (c.sections||[])) {
  children.push(new Paragraph({ heading:HeadingLevel.HEADING_1,
    border:{bottom:{style:BorderStyle.SINGLE,size:6,color:BLUE,space:2}}, children:[t(s.heading||"")] }));
  for (const b of (s.blocks||[])) children.push(block(b));
}

const doc = new Document({
  styles:{ default:{document:{run:{font:"Arial",size:22}}},
    paragraphStyles:[{ id:"Heading1", name:"Heading 1", basedOn:"Normal", next:"Normal", quickFormat:true,
      run:{size:28,bold:true,font:"Arial",color:NAVY}, paragraph:{spacing:{before:320,after:160},outlineLevel:0} }] },
  numbering:{ config:[
    { reference:"bullets", levels:[{level:0,format:LevelFormat.BULLET,text:"•",alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:540,hanging:270}}}}] },
    { reference:"nums", levels:[{level:0,format:LevelFormat.DECIMAL,text:"%1.",alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:540,hanging:270}}}}] },
  ] },
  sections:[{ properties:{page:{size:{width:12240,height:15840},margin:{top:1440,right:1440,bottom:1440,left:1440}}}, children }],
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync(outPath, b); console.log("wrote "+outPath); });
