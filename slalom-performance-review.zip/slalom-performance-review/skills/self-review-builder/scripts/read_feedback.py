#!/usr/bin/env python3
"""
Read a feedback export, filter to a review period, and group quotes by pillar/badge.

Usage:
  python3 read_feedback.py <feedback.xlsx|.csv> [--since YYYY-MM-DD] [--json]

Reads a sheet/CSV with columns like: Date, From, Feedback, Badge (case-insensitive,
flexible). Prints quotes grouped, newest first. No data is stored or sent anywhere.
"""
import argparse, csv, json, sys, datetime, re

def parse_date(v):
    if v is None: return None
    if isinstance(v, (datetime.datetime, datetime.date)):
        return datetime.date(v.year, v.month, v.day)
    s = str(v).strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d %H:%M:%S"):
        try: return datetime.datetime.strptime(s[:len(fmt)+2], fmt).date()
        except ValueError: continue
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m: return datetime.date(int(m[1]), int(m[2]), int(m[3]))
    return None

def find(colnames, *cands):
    low = {c.lower().strip(): i for i, c in enumerate(colnames)}
    for cand in cands:
        for k, i in low.items():
            if cand in k: return i
    return None

def load_rows(path):
    if path.lower().endswith((".xlsx", ".xlsm")):
        try:
            import openpyxl
        except ImportError:
            sys.exit("openpyxl not installed: pip install openpyxl --break-system-packages")
        wb = openpyxl.load_workbook(path, data_only=True)
        ws = wb[wb.sheetnames[0]]
        rows = [[c for c in r] for r in ws.iter_rows(values_only=True)]
    else:
        with open(path, newline="", encoding="utf-8-sig") as f:
            rows = [r for r in csv.reader(f)]
    # find the header row (first row containing a 'feedback' cell)
    hdr = 0
    for i, r in enumerate(rows[:5]):
        if any(str(c).lower().strip() == "feedback" for c in r if c is not None):
            hdr = i; break
    return rows[hdr], rows[hdr+1:]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--since", default=f"{datetime.date.today().year}-01-01")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    since = parse_date(a.since)
    header, data = load_rows(a.path)
    ci = {
        "date": find(header, "date"),
        "from": find(header, "from", "reviewer", "author"),
        "feedback": find(header, "feedback", "comment"),
        "badge": find(header, "badge", "pillar", "relates", "competency"),
    }
    out = []
    for r in data:
        def g(k):
            i = ci[k]
            return r[i] if (i is not None and i < len(r)) else None
        d = parse_date(g("date"))
        fb = g("feedback")
        if not fb or not str(fb).strip(): continue
        if since and d and d < since: continue
        name = str(g("from") or "").split("\n")[-1].strip()
        out.append({"date": d.isoformat() if d else None,
                    "from": name, "badge": (str(g("badge")).strip() if g("badge") else None),
                    "feedback": str(fb).strip()})
    out.sort(key=lambda x: x["date"] or "", reverse=True)
    if a.json:
        print(json.dumps(out, indent=2)); return
    print(f"{len(out)} feedback entries since {since}\n" + "="*60)
    for e in out:
        print(f"\n[{e['date']}] {e['from']}  ({e['badge'] or 'no badge'})\n{e['feedback']}")

if __name__ == "__main__":
    main()
