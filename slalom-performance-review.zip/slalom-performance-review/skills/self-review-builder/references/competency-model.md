# me@slalom Competency Model — cached fallback

> SOURCE OF TRUTH IS LIVE SHAREPOINT. This is a thin, version-stamped snapshot used only when the live fetch fails.
> Snapshot of: "me@slalom Career Framework Role Profiles" + "Core Competency Supplement" (2025 refreshed model).
> Snapshot date: 2026-06 · Refresh when me@slalom changes.

The model has four categories ("pillars"), each with sub-competencies:

## Deliver Exceptionally
- Delivery Management
- Delivery Quality and Impact
- Communication and Influence
- Value-Based Delivery (expand conversations beyond the immediate engagement; craft compelling narratives)
- Customer Relationship Management (relationships across multiple levels/areas; act on Customer Love)

## Grow Expertise
- Associated Roles (role mastery)
- Learning and Development (lead with curiosity; build/leverage capability, industry, or solution knowledge; enable shadowing)
- Knowledge Management (thought leadership and stories; set team standards)
- Solution Enablement (use industry/client insight to inform Slalom solutions, offerings, accelerators)

## Grow Slalom
- Culture and Community (model values; create connection)
- Business Strategy and Planning (adjust strategy to market-demand signals)
- Business Operations (financial metrics: oversee engagement financials / account performance / focus-area targets by track)
- Talent Strategy
- Networking and Brand Stewardship (elevator pitch and client stories at AC–Principal; partner with marketing / host clients at Senior Principal+)
- Business Development and Sales

## Lead
- Self Management (self-awareness; career development; continuous learning)
- Feedback (cultural norm; 360 and upward; Situation-Behavior-Impact (SBI) model)
- Collaboration (coaching, communication, conflict resolution, inclusion, EQ, trust)
- Change Leadership (navigate ambiguity; balance resilience and flexibility with empathy)
- Vision & Strategy
- Career Development (People Leadership) — team members' aspirations, interests, growth trajectory
- Performance Management (People Leadership) — fair, consistent, objective assessment vs. standards
