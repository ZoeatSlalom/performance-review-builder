# Track × Level emphasis — cached heuristic fallback

> Confirm against the live me@slalom Role Profiles for the person's exact track and level. This is directional guidance for where the narrative's weight should sit, not the official wording.

Levels covered: Consultant → Senior Consultant → Principal → Senior Principal.
(Optional delivery-track variants such as Senior Delivery Principal sit between Principal and Senior Principal — treat similarly to the adjacent level, leaning toward delivery leadership.)

## Where the review's weight sits by level

| Level | Leads with | Also show |
|-------|-----------|-----------|
| Consultant | Deliver Exceptionally (execution, quality), Grow Expertise (build mastery) | Collaboration; growing client-facing presence |
| Senior Consultant | Deliver Exceptionally at scale + Value-Based Delivery; Grow Expertise (reusable IP, mentoring) | Early sales/pursuit support; develops others; community |
| Principal | Business Development & Sales; account/engagement leadership; People Leadership; engagement **financials** | Continued delivery excellence; firm-building; thought leadership |
| Senior Principal | Sales and portfolio growth; market/offering strategy; developing leaders; brand stewardship (host clients, partner with marketing) | Org-level impact; financial ownership of a focus area/portfolio |

## Promotion logic
Argue evidence against the **next** level's bar. The higher the level, the more the case rests on revenue/sales credit, account growth, people leadership outcomes, and financial ownership — not delivery volume.
