# Workstream → pillar mapping rubric

Route each workstream and each feedback quote to its **primary** pillar. Many items touch several — choose the dominant competency, and you may reference a second pillar briefly.

| If the work is mainly about... | Primary pillar |
|---|---|
| Delivering client outcomes, quality, facilitation, shipping working solutions, expanding scope from a delivery relationship | **Deliver Exceptionally** |
| Building skills/credentials, creating reusable IP/curriculum/accelerators, codifying knowledge, staying current | **Grow Expertise** |
| Sales, pursuits/proposals, GTM, offerings, account growth, community/culture, brand, engagement financials | **Grow Slalom** |
| Developing others, people leadership, mentoring/coaching, self-development, collaboration, leading through ambiguity | **Lead** |

## Rules
- Quantify impact wherever possible; a pillar claim is only as strong as its evidence.
- Certifications and "trained myself" → Grow Expertise (capability) and/or Lead (develop self). Coaching/training *others* → Lead (develop others) and/or Grow Expertise (knowledge management).
- Pre-sales and pipeline → Grow Slalom even if unbilled; tie to sales credit when available.
- Community/ERG/Aspire programming → Grow Slalom (Culture and Community / Networking and Brand Stewardship).
- People-leader duties (performance assessments for reports) → Lead (People Leadership) — and call out that it is above-level scope for ICs.
- Weight selection by level (see track-level-profiles.md): higher levels lead with Grow Slalom and Lead.
