# Golden example (anonymized) — quality bar for structure and voice

> Synthetic. Names, clients, and numbers are placeholders. Use for shape and tone, not content.

**Mid-Year Self Review — [Name] | [Level]**

## 1. Outcomes & quantitative expectations to date
Utilization: [__% YTD vs. __% target]
Sales / contribution credit: [$___ / ___ points; note deals]
This half delivered measurable, at-scale impact: [N]+ people enabled, [N]+ solutions shipped, [N]% lift in [metric].
- [Engagement A]: designed and deployed [capability] for [N] users — shipped [N] working tools, cut [task] time [N]%, built a [N]-champion adoption model. A repeatable model, not a pilot.
- [IP]: built [reusable asset], now the standard for [scope].
- Pipeline: shaped [pursuits], resulting in [X] sales credit.

## 2. Impact & growth across me@slalom competencies
**Deliver Exceptionally** — [outcome with numbers]. As [Reviewer] noted, I "[verbatim quote]."
**Grow Expertise** — [credential/IP]; turned expertise into reusable assets. As [Reviewer] put it, my work created "[verbatim quote]."
**Grow Slalom** — [sales/GTM/community with numbers]. [Reviewer] said I "[verbatim quote]."
**Lead** — [develop self + develop others]; acted as people leader to a report. [Reviewer] noted my [leadership] "[verbatim quote]."

## 3. How I'll elevate in H2
1. [Convert pipeline to credited revenue].
2. [Productize/scale an offering].
3. [Stand up a leadership/community initiative].
4. [Grow influence: thought leadership + external conferences].
