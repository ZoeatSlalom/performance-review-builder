# Promo-framing guide (how to write a self-review that advocates well)

Goal: a confident, honest case that the person is meeting their level and, for a promo, already operating at the next one. Memorable to a busy reviewer.

## Principles
- **Lead with quantified outcomes.** Open each answer with the result, then the activity (e.g., "trained 1,200+ people; built 50+ tools; cut research time 95%+").
- **Operate-above-level framing (promo).** Explicitly name responsibilities beyond the current title (owning a report's performance assessment, shaping sales, building firm IP) and argue against the *next* level's bar.
- **Weave feedback inline, verbatim, attributed.** `As <Name> noted, I "<quote>."` Place each quote under the pillar it best evidences. Never paraphrase a quote inside quotation marks.
- **Outcomes over activity.** "Shipped working systems, not POCs." Show reuse, scale, adoption, and follow-on scope.
- **Be specific and credible.** Concrete numbers and named engagements beat adjectives. Avoid filler ("very", "passionate", "synergy") and avoid overclaiming — reviewers discount inflated language.
- **Placeholders, never invented numbers.** Mark utilization and sales/credit as `[ ... ]` for the user to fill. Do not estimate them.
- **Tone:** confident and warm, first person, tight prose. Match any tone the user specifies.

## Structure per answer
Result → what you did → impact/scale → (feedback quote) → forward hook where relevant.

## Level dial
- Consultant/SC: weight delivery quality, growing expertise, reliability, emerging leadership.
- Principal/Senior Principal: weight sales/revenue, account & portfolio leadership, developing others, engagement financials, brand. Delivery is assumed, not the headline.
