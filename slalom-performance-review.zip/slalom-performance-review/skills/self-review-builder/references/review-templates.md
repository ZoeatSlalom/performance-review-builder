# Candidate question sets — CONFIRM against the live Workday form

> Always show these and ask the user to confirm or paste the exact prompts from their current Workday self-reflection. Wording changes per cycle. Do not assume.

## Mid-year (observed 2026 set)
1. Capture outcomes such as quantitative expectations achieved to date (utilization, sales, revenue, etc.).
2. Highlight your impact and growth so far this year based on your me@slalom competencies overall.
3. What are a few ways you can elevate your performance in the second half of the year?

## Annual (typical variant — confirm)
1. Summarize your key outcomes and quantitative results for the year.
2. Describe your impact and growth across the me@slalom competencies.
3. What are your development priorities and goals for next year?

## Promotion case (supplement to the above — confirm)
- Evidence that you are already operating at the next level, organized by pillar.
- Scope, complexity, and autonomy of your work vs. current-level expectations.
- Sales/revenue contribution, people leadership, and firm-building beyond delivery.
