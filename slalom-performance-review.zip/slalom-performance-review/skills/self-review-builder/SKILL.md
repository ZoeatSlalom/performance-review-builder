---
name: self-review-builder
description: >
  Write a Slalom me@slalom self-review — mid-year, annual, or a promotion case — for any team member from Consultant through Senior Principal. Use when the user asks to write, draft, build, or improve their self review, self-reflection, performance review, me@slalom review, year-end/mid-year review, or promotion (promo) case/packet. Maps their work to the four me@slalom pillars, weaves in feedback, and leaves utilization and sales as placeholders.
compatibility: Cowork desktop. Best with a connected Microsoft 365 (Graph) connector; degrades to interview-only without it.
---

# Self-Review Builder

Produce a strong, competency-mapped me@slalom self-review. Default posture: advocate for the person honestly and confidently, mapped to their level, grounded only in real evidence they provide or that is pulled from their connectors. Never fabricate metrics, quotes, projects, or outcomes.

Run the workflow in order. Gather what you can first; ask only for genuine gaps; then write.

## Phase 1 — Frame the review

1. Determine **review type** (mid-year / annual / promotion), **track** (Client Delivery / Account / Market Solutions / Build), and **role level** (Consultant, Senior Consultant, Principal, Senior Principal). Ask only what you cannot infer.
2. **Source the questions, do not assume them.** Load the candidate question set for the review type from `references/review-templates.md`, show it, and ask the user to confirm or paste the exact prompts from their current Workday self-reflection. Wording changes per cycle and Workday is not connected. The confirmed questions define the output structure.
3. Establish **intent**: standard check-in vs. promotion-positioned. For promotion, frame evidence against the *next* level's bar (see `references/promo-framing-guide.md`).

## Phase 2 — Load the competency model (live first)

1. Fetch the me@slalom framework **live from SharePoint** via the Microsoft Graph connector — target the canonical "me@slalom Career Framework Role Profiles" document, not a broad search (the term returns thousands of lookalikes). Pull the four pillars, sub-competencies, and the expectations for the user's **track × level**.
2. If the connector is unavailable or the fetch fails, fall back to the version-stamped snapshot in `references/competency-model.md` and `references/track-level-profiles.md`, and tell the user you used the cached copy.

## Phase 3 — Gather workstreams & impact (interview-led)

1. **Ask for existing context first**: "Do you have anything already written down — an accomplishment tracker, brag doc, weekly notes, a prior review, or a resume — you'd like me to pull from?" If they point to a file or folder, read it, extract candidate workstreams and impact, and confirm each item with the user. Optional; never require it.
2. **Interview the user**: "What did you work on this period, and what was the outcome or impact of each?" Capture project, role, what they did, and quantified impact where possible. Not everyone has anything pre-organized — the interview is the primary source, with any provided context as the starting point.
3. Use connectors **only as accelerants** to prefill or jog memory: Outlook/Teams/calendar for projects and recognition. Always confirm prefilled items with the user.
4. For each workstream, record concrete impact (numbers, scope, adoption, reuse, client/stakeholder reaction). Push gently for quantification.

## Phase 4 — Feedback (opt-in; no Workday connector)

1. Ask whether the user wants to **include feedback quotes**. There is no Workday connector, so feedback cannot be auto-pulled.
2. If yes: have them paste the feedback or point to an export/file, then run `scripts/read_feedback.py <file>` to filter to the review period and group quotes by pillar/badge. Quote verbatim; attribute by name.
3. If no: skip quotes entirely.

## Phase 5 — Map work to pillars

Use `references/pillar-mapping-rubric.md` to route each workstream and each feedback quote to its primary pillar. Many items touch several pillars — pick the dominant competency. Weight by level: Consultant/SC reviews lead with Deliver Exceptionally and Grow Expertise; Principal/Senior Principal reviews must lead with business development/sales, account & portfolio leadership, developing others, and engagement financials (Grow Slalom and Lead).

## Phase 6 — Draft

1. Answer **each confirmed question** in order. Put the four-pillar mapping inside whichever question asks about competencies/growth; give the others their own evidence.
2. Lead with quantified outcomes. Weave feedback inline as natural sentences — e.g., `As <Name> noted, I "<verbatim quote>."` — not as a separate block.
3. Leave **utilization and sales/credit as clearly marked placeholders** unless the user supplies numbers. Never invent them.
4. Apply `references/promo-framing-guide.md`. Keep claims honest and specific; avoid filler. Match the tone the user requested.
5. Use `references/golden-example.md` as the quality bar for structure and voice.

## Phase 7 — Output & verify

1. Produce **paste-ready text** by default. If the user wants a Word document, build it with `scripts/build_review_docx.js <content.json> <out.docx>` (requires `npm install docx`); fall back to text if unavailable.
2. Verify before delivering: every confirmed question answered; all four pillars represented in the competency answer; only user-provided feedback quoted; placeholders intact; nothing fabricated.
3. Save to the user's chosen folder and present the file.

## Degraded / unattended mode

If run without a person to answer questions (e.g., scheduled), do not block: produce the best draft from available connector/folder evidence, leave gaps as labeled placeholders, and list what the user must supply (questions to confirm, feedback, metrics).

## Guardrails

- Ship and store **no real performance data**. Read sensitive inputs only at runtime from user-specified paths; write only to the user's chosen output folder.
- Quote only feedback the user provides. Offer a "redact names" mode for shareable drafts.
- Request only Read, Write, and Bash. Reuse the user's existing connectors; never embed credentials.
